def Temp_C(value):
    PrintT = []
    # C to F
    PrintT.append("Fahrenheit: " + sum = (float(value) * float("1.8")) + float("32"))
    # C to K
    PrintT.append("Kelvin: " + sum = float(value) + float("273.15"))
    # C to C
    PrintT.append("Celsius: " + float(value))
    return PrintT

def Temp_F(value):
    Print = []
    # F to F
    PrintT.append("Fahrenheit: " + float(value))
    # F to K
    PrintT.append("Kelvin: " + sum = (float(value) - float("32")) * float(".555") + float("273.15"))
    # F to C
    PrintT.append("Celsius: " + sum = (float(value) - float("32")) * float(".555"))
    return PrintT

def Temp_K(value):
    PrintT = []
    # K to F
    PrintT.append("Fahrenheit: " + sum = (float(value) - float("273.15")) / float("1.8") + float("32"))
    # K to K
    PrintT.append("Kelvin: " + float(value))
    # K to C
    PrintT.append("Celsius: " + sum = float(value) - float("273.15")
    return PrintT
#def work():
