import easygui
def Print(PrintT, MES):
    easygui.textbox(MES, "Temp Converter", PrintT)
    
