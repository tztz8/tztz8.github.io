from Temp_Converter_Module import*
def Wind_Chill():
	PrintT = []
	PrintT.append("%")